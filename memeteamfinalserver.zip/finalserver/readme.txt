Author: Meme_team
Date: 4/23/17



How to compile (type in shell):

make

to remove compiled code:

make clean

to run:

./server

Files get saved in spreadsheets
